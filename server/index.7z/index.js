const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mysql = require('mysql');
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  next();
});
// parse application/json
app.use(bodyParser.json());

//create database connection
const conn = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: '123456',
  database: 'gstn'
});
 
//connect to database
conn.connect((err) =>{
  if(err) throw err.sqlState;
  console.log('Mysql Connected...' +'\n' +
  "Get all data : http://localhost:3000/api/getart"+'\n' +
  "Add New article : http://localhost:3000/api/articles"+'\n' +
  "update article : http://localhost:3000/api/update-article/:id"+'\n' +
  "Delete article : http://localhost:3000/api/delete-article/:id"+'\n' +
  "get single article : http://localhost:3000/api/articles/:id"+'\n' 
  );
});
 
//show all articles
app.get('/api/getart',(req, res) => {
  let sql = "SELECT * FROM article";
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
 
//show single article
app.get('/api/articles/:id',(req, res) => {
  let sql = "SELECT * FROM article WHERE id="+req.params.id;
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
 
//add new article
app.post('/api/articles',(req, res) => {

  let data = {category: req.body.category, title: req.body.title,  phone: req.body.phone};
  
  let sql = "INSERT INTO article SET ?";
  let query = conn.query(sql, data,(err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
 
//update article
app.put('/api/update-article/:id',(req, res) => {
  let sql = "UPDATE article SET title='"+req.body.title+"', category='"+req.body.category+"', phone='"+req.body.phone+"' WHERE id="+req.params.id;
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
 
//Delete article
app.delete('/api/delete-article/:id',(req, res) => {
  let sql = "DELETE FROM article WHERE id="+req.params.id+"";
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
      res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
 
//Server listening
app.listen(3000,() =>{
  console.log('Server started on port 3000...');
});